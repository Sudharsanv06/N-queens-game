import mongoose from 'mongoose'

const gameSchema = new mongoose.Schema({
  size: Number,
  queens: [[Number]],
  createdAt: {
    type: Date,
    default: Date.now
  }
})

export default mongoose.model('Game', gameSchema)
