import express from 'express'
import Game from '../models/Game.js'

const router = express.Router()

// Save game
router.post('/', async (req, res) => {
  const { size, queens } = req.body
  try {
    const newGame = new Game({ size, queens })
    await newGame.save()
    res.status(201).json({ message: 'Game saved' })
  } catch (err) {
    res.status(500).json({ error: 'Could not save game' })
  }
})

export default router
