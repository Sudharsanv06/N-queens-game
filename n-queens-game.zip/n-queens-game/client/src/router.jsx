// client/src/router.jsx
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Main from './components/Main';
import Login from './components/Login';
import Signup from './components/Signup';
import App from './components/App'; // N-Queens Game

const Router = () => {
  return (
    <Routes>
      <Route path="/" element={<Main />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/game" element={<App />} />
    </Routes>
  );
};

export default Router;
