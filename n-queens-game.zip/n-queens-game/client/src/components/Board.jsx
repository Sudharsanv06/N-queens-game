// client/src/components/Board.jsx
import React, { useState } from 'react';
import Cell from './Cell';
import axios from 'axios';

const Board = ({ size }) => {
  const [queens, setQueens] = useState([]);

  const isSafe = (row, col) => {
    return !queens.some(([r, c]) =>
      r === row || c === col || Math.abs(r - row) === Math.abs(c - col)
    );
  };

  const handleCellClick = (row, col) => {
    const exists = queens.find(([r, c]) => r === row && c === col);
    if (exists) {
      setQueens(queens.filter(([r, c]) => !(r === row && c === col)));
    } else if (isSafe(row, col)) {
      setQueens([...queens, [row, col]]);
    }
  };

  const resetBoard = () => setQueens([]);

  const validateSolution = () => {
    if (queens.length !== size) {
      alert(`Place exactly ${size} queens.`);
      return;
    }

    const isValid = queens.every(([r1, c1], i) =>
      queens.slice(i + 1).every(([r2, c2]) =>
        r1 !== r2 && c1 !== c2 && Math.abs(r1 - r2) !== Math.abs(c1 - c2)
      )
    );

    alert(isValid ? 'Valid solution!' : 'Invalid N-Queens configuration.');
  };

  const saveToDB = async () => {
    try {
      await axios.post('http://localhost:5000/api/games', { size, queens });
      alert('Game saved to database!');
    } catch (err) {
      alert('Error saving to DB.');
    }
  };

  return (
    <div>
      <div
        className="board"
        style={{ gridTemplateColumns: `repeat(${size}, 40px)` }}
      >
        {[...Array(size)].map((_, row) =>
          [...Array(size)].map((_, col) => (
            <Cell
              key={`${row}-${col}`}
              row={row}
              col={col}
              hasQueen={queens.some(([r, c]) => r === row && c === col)}
              onClick={() => handleCellClick(row, col)}
            />
          ))
        )}
      </div>

      <div className="buttons">
        <button onClick={resetBoard}>Reset Board</button>
        <button onClick={validateSolution}>Validate</button>
        <button onClick={saveToDB}>Save to DB</button>
      </div>
    </div>
  );
};

export default Board;
