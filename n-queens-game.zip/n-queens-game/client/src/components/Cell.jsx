// client/src/components/Cell.jsx
import React from 'react';

const Cell = ({ row, col, hasQueen, onClick }) => {
  return (
    <div
      className={`cell ${hasQueen ? 'queen' : ''}`}
      onClick={onClick}
    >
      {hasQueen ? '♛' : ''}
    </div>
  );
};

export default Cell;
